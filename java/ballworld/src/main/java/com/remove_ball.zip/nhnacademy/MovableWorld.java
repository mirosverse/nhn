package com.nhnacademy;

import java.util.ArrayList;
import java.util.List;

public class MovableWorld extends World {
    int moveCount;
    int maxMoveCount = 0;
    int dt;

    public void reset() {
        moveCount = 0;
    }

    public void move() {
        List<Ball> removeList = new ArrayList<>();
        if ((getMaxMoveCount() == 0) || (getMoveCount() < getMaxMoveCount())) {
            for (int i = 0; i < getCount(); i++) {
                Ball ball = get(i);
                if (ball instanceof MovableBall) {
                    ((MovableBall) ball).move();

                    for (int j = 0; j < getCount(); j++) {
                        Ball otherBall = get(j);

                        if (ball != otherBall && ball.isCollision(otherBall)) {
                            ((BoundedBall) ball).bounce(otherBall);
                            removeList.add(otherBall);
                            logger.info("ball({})와 ball({})이 충돌하였습니다.", ball.getId(), otherBall.getId());
                        }

                    }
                }
            }

            for (Ball ball : removeList) {
                remove(ball);
                
            }

            moveCount++;
            repaint();
        }
    }

    public int getDt() {
        if (dt < 0) {
            throw new IllegalArgumentException();
        }
        return dt;
    }

    public void setDt(int dt) {
        this.dt = dt;
    }

    public void run() {
        while (!Thread.currentThread().isInterrupted()) {
            move();
            try {
                Thread.sleep(dt);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public int getMoveCount() {
        return moveCount;
    }

    public int getMaxMoveCount() {
        return maxMoveCount;
    }

    public void setMaxMoveCount(int count) {
        if (count < 0) {
            throw new IllegalArgumentException();
        }

        maxMoveCount = count;
    }

}