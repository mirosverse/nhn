package com.nhnacademy;

import java.awt.Color;
import java.awt.Rectangle;

public class BoundedBall extends MovableBall {

    public BoundedBall(int x, int y, int radius, Color color) {
        super(x, y, radius, color);
    }

    Rectangle bounds;

    public Rectangle getBounds() {
        return bounds;
    }

    public void setBounds(Rectangle bounds) {
        this.bounds = bounds;
    }

    public boolean isOutOfBounds() {
        return (bounds.intersects(getRegion()));
    }

    @Override
    public void move() {
        super.move();
        if (isOutOfBounds()) {
            bounce();
        }
    }

    public void bounce() {
        if (bounds.getMinX() > getX() - getRadius() || bounds.getMaxX() < getX() + getRadius()) {
            setDX(-getDX());
        }
        if (bounds.getMinY() > getY() - getRadius() || bounds.getMaxY() < getY() + getRadius()) {
            setDY(-getDY());
        }
    }

    public void bounce(Ball otherBall) {
        if (bounds.getCenterX() == otherBall.getX()) { // 2, 7
            setDY(-getDY());
        } else if (bounds.getCenterY() == otherBall.getY()) { // 4, 5
            setDX(-getDX());
        } else {
            setDX(-getDX());
            setDY(-getDY());
        }
    }
}
