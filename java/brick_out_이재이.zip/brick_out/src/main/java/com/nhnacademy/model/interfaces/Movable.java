package com.nhnacademy.model.interfaces;

public interface Movable {

    void move();
}
