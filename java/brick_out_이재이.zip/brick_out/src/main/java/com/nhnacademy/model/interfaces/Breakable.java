package com.nhnacademy.model.interfaces;

public interface Breakable {
    boolean isBroken();
}
