package com.nhnacademy;

public class Main {
    public static void main(String[] args) {
        Market market = new Market();
        market.run();
        market.close();
    }
}